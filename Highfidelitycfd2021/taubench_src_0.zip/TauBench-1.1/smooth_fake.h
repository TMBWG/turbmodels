#ifndef SMOOTH_FAKE_H
#define SMOOTH_FAKE_H

void kernel_3_0(DualGrid *grid, 
		WorkSpace *work,
		double dummy_4[][CO],
		double dummy_3[][AD],
		double dummy_1[][PR],
		int sm,
		int re,int id,int prn);

#endif

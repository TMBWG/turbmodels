#ifndef LIM_FAKE_H
#define LIM_FAKE_H
void kernel_1_0(DualGrid *grid, 
	      WorkSpace *work, 
	      double dummy_1[][PR],
	      double dummy_2[][GR][3],
	      double sc, 
	      double scp,int id,int prn);

#endif



















#ifndef FAKE_MAIN_H
#define FAKE_MAIN_H

void *test_malloc(int pnt);

double second();

#endif

#ifndef FLUX_FAKE_H
#define FLUX_FAKE_H

void kernel_2_0(DualGrid *grid, 
	      WorkSpace *work, 
	      double dummy_1[][PR],
	      double dummy_3[][AD],
	      double dummy_2[][GR][3], 
	      double dummy_4[][CO],int id,int prn);

#endif
